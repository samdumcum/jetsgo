<?php
/*
Template Name: Wide Page
*/
?>

<?php get_header(); ?>

-->Write awesome travel Info Here<--
<p>Hey JetsGo Theme User,</p>
<p>This is a WIDE page with NO side-bar.</p>
<p> But it will still feature the header and footer!</p>
<p> #TravelOn</p>

<?php get_footer(); ?>